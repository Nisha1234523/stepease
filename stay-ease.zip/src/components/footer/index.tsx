import { Link } from "react-router-dom";

function Footer() {
  return (
    <>
      {/* Footer Start */}
      <div className="bg-blue mt-5">
        <footer className="py-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3">
            <div className="row m-0 gy-lg-5 gy-4 gx-md-3 gx-0">
              <div className="col-12">
                <Link to="/" className="navbar-brand">
                  <h2 className="text-white fw-bold fs-36">StayEase</h2>
                </Link>
              </div>
              <div className="col-lg-3 col-md-5 mt-0">
                <p className="fw-normal fs-18 light-text col-lg-8 mt-3">
                  We offer best hotel booking services and facilities for your
                  comfortable stay.
                </p>
              </div>

              <div className="col-lg-2 col-md-4 col-6 mt-0">
                <h6 className="fw-bold fs-20 text-white">About us</h6>
                <ul className="nav flex-column">
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none text-white fs-16"
                    >
                      Blog
                    </Link>
                  </li>
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-normal p-0 text-decoration-none text-white fs-16"
                    >
                      FAQ’s
                    </Link>
                  </li>
                  <li className="mt-2 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none  text-white fs-16"
                    >
                      Contact Us
                    </Link>
                  </li>
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none text-white fs-16"
                    >
                      Careers
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="col-lg-2 col-md-3 col-6 mt-0">
                <h6 className="fw-bold fs-20 text-white">Popular Hotels</h6>
                <ul className="nav flex-column">
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none text-white fs-16"
                    >
                      Luxurious Hotel
                    </Link>
                  </li>
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-normal p-0 text-decoration-none text-white fs-16"
                    >
                      Savana Hotel
                    </Link>
                  </li>
                  <li className="mt-2 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none  text-white fs-16"
                    >
                      Capital Hotel
                    </Link>
                  </li>
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none text-white fs-16"
                    >
                      Hyyatt Hotels
                    </Link>
                  </li>
                </ul>
              </div>

              <div className="col-lg-2 col-sm-5 col-6 mt-md-0 mt-5">
                <h6 className="fw-bold fs-20 text-white footer-item">
                  Our Packages
                </h6>
                <ul className="nav flex-column">
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none text-white fs-16"
                    >
                      Premium Package
                    </Link>
                  </li>
                  <li className="mt-2 pt-1 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-normal p-0 text-decoration-none text-white fs-16"
                    >
                      Standard Package
                    </Link>
                  </li>
                  <li className="mt-2 nav-item footer-item">
                    <Link
                      to="/"
                      className="fw-medium p-0 text-decoration-none  text-white fs-16"
                    >
                      Basic Package
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="col-lg-3 col-sm-6 col-sm-7  mt-md-0">
                <div className="form-control position-relative w-100 mt-3 newletter-form">
                  <input
                    type="text"
                    className="form-input fw-medium fw-16 w-100 bg-transparent py-2 opacity-25 newletter"
                    placeholder="Enter your email"
                  />
                  <button
                    type="button"
                    className="fs-16 fw-medium position-absolute top-0 end-0 text-white form-btn px-4"
                  >
                    Subscribe
                  </button>
                </div>
              </div>

              {/*  */}
              <hr className="text-white my-4 opacity-50 rounded-5 divider" />

              <div className="d-flex flex-sm-row flex-column  align-items-center  justify-content-sm-between justify-content-center">
                <div>
                  <p className="mb-0 text-white w-fit mx-sm-0 mx-auto fw-normal">
                    All rights reserved @StayEase
                  </p>
                </div>
                {/* social-items */}
                <div className="d-flex align-items-center justify-content-center justify-content-md-start gap-3 mt-sm-0 mt-4">
                  <Link
                    to="/"
                    className="bg-primary d-flex justify-content-center align-items-center rounded-circle p-2"
                  >
                    <img
                      src="/static/img/icons/ic-facebook.svg"
                      alt="Facebook Icon"
                    />
                  </Link>

                  <Link
                    to="/"
                    className="bg-primary d-flex justify-content-center align-items-center rounded-circle p-2"
                  >
                    <img
                      src="/static/img/icons/ic-insta.svg"
                      alt="Insta Icon"
                    />
                  </Link>

                  <Link
                    to="/"
                    className="bg-primary d-flex justify-content-center align-items-center rounded-circle p-2 "
                  >
                    <img
                      src="/static/img/icons/ic-twitter.svg"
                      alt="Twitter Icon"
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
      {/* Footer End */}
    </>
  );
}

export default Footer;
