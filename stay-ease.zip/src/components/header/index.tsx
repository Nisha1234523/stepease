import { Link } from "react-router-dom";

const Header = () => {
  return (
    <>
      <nav className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <Link to="/" className="navbar-brand">
            <h2 className="text-white fw-bold d-lg-none d-block fs-36">
              StayEase
            </h2>
          </Link>
          <button
            className="navbar-toggler shadow-none border-0 px-0 collapsed"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-between align-items-center"
            id="navbarSupportedContent"
          >
            <Link to="/" className="navbar-brand d-lg-block d-none">
              <h2 className="text-white fs-36">StayEase</h2>
            </Link>
            <ul className="navbar-nav mb-2 mb-lg-0 header">
              <li className="nav-item me-4">
                <Link
                  to="/"
                  className="nav-link active fw-bold fs-16 text-white"
                  aria-current="page"
                >
                  Home
                </Link>
              </li>
              <li className="nav-item me-4">
                <Link to="/about" className="nav-link fw-bold fs-16 text-white">
                  About us
                </Link>
              </li>
              <li className="nav-item me-4">
                <Link
                  to="/contact"
                  className="nav-link fw-bold fs-16 text-white"
                >
                  Contact Us
                </Link>
              </li>
              <li className="nav-item me-4">
                <Link
                  to="/packages"
                  className="nav-link fw-bold fs-16 text-white"
                >
                  Our Packages
                </Link>
              </li>
              <li className="nav-item me-4">
                <Link to="/" className="nav-link fw-bold fs-16 text-white">
                  Help
                </Link>
              </li>
            </ul>
            <button type="button" className="primary-btn">
              <Link to="/login" className="text-white text-decoration-none">
                Login
              </Link>
            </button>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Header;
