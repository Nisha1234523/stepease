import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Footer from "../../components/footer";

function Confirmbooking() {
  const [days, setDays] = useState([]);
  const [months] = useState([
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]);
  const [years, setYears] = useState([]);

  const [selectedMonth, setSelectedMonth] = useState("");
  const [selectedYear, setSelectedYear] = useState("");

  useEffect(() => {
    // Populate the year options from current year to 1900
    const currentYear = new Date().getFullYear();
    const availableYears = [];
    for (let i = currentYear; i >= 1900; i--) {
      availableYears.push(i);
    }
    setYears(availableYears);
  }, []);

  useEffect(() => {
    // Adjust days based on selected month and year
    if (selectedMonth && selectedYear) {
      const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
      const availableDays = [];
      for (let i = 1; i <= daysInMonth; i++) {
        availableDays.push(i);
      }
      setDays(availableDays);
    }
  }, [selectedMonth, selectedYear]);

  return (
    <>
      <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-50">
        <div className="text-center">
          <h2 className="fw-bold heading primary-text">Confirm Booking</h2>
        </div>

        <div className="row mt-50">
          <div className="col-xl-3 col-lg-4 col-md-6 border-r p-5">
            {/* Payment Methods */}
            <span className="fs-24 fw-bold d-flex gap-3 bg-light p-1">
              <img
                src="/static/img/icons/ic-credit.svg"
                alt="Credit Card"
                className="img-fluid"
              />
              Credit Card
            </span>

            <span className="fs-24 fw-bold d-flex gap-3 p-1 mt-4">
              <img
                src="/static/img/icons/ic-debit.svg"
                alt="Debit Card"
                className="img-fluid"
              />
              Debit Card
            </span>

            <span className="fs-24 fw-bold d-flex gap-1 p-1 mt-4">
              <img
                src="/static/img/icons/ic-upi.svg"
                alt="UPI Payment"
                className="img-fluid w-auto"
              />
              UPI Payment
            </span>

            <span className="fs-24 fw-bold d-flex gap-3 p-1 mt-4">
              <img
                src="/static/img/icons/ic-qr.svg"
                alt="QR Code"
                className="img-fluid"
              />
              Scan QR Code
            </span>
          </div>
          <div className="col-xl-9 col-lg-8 ps-5">
            {/* Form Section */}
            <form>
              <h2 className="fw-bold fs-24">Payment Information</h2>
              <div className="form-main mt-5">
                <div className="row">
                  {/* Name on Card */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="name" className="mb-2 blue-text">
                        Name on Card
                      </label>
                      <input
                        type="text"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="name"
                        aria-describedby="name"
                      />
                    </div>
                  </div>

                  {/* Credit Card Number */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="cardnumber" className="mb-2 blue-text">
                        Credit Card Number*
                      </label>
                      <input
                        id="cardnumber"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        type="text"
                        pattern="[0-9]*"
                        inputMode="numeric"
                        maxLength="19"
                        autocomplete="off"
                      />
                    </div>
                  </div>

                  {/* Expiration Date */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="expiration" className="mb-2 blue-text">
                        Expiration Date *
                      </label>
                      <div className="row">
                        <div className="col-6">
                          <select
                            id="birthMonth"
                            className="input-h form-control border-secondary-subtle month-data"
                            value={selectedMonth}
                            onChange={(e) => setSelectedMonth(e.target.value)}
                          >
                            <option value="">Month</option>
                            {months.map((month, index) => (
                              <option key={index} value={index + 1}>
                                {month}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-6">
                          <select
                            id="birthYear"
                            className="input-h form-control border-secondary-subtle month-data"
                            value={selectedYear}
                            onChange={(e) => setSelectedYear(e.target.value)}
                          >
                            <option value="" className="blue-text">
                              Year
                            </option>
                            {years.map((year) => (
                              <option key={year} value={year}>
                                {year}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* CVV */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="cvv" className="mb-2 blue-text">
                        CVV/CVC *
                      </label>
                      <input
                        type="password"
                        className="form-control input-h shadow-none border-secondary-subtle"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Billing Address */}
              <h2 className="fw-bold fs-24 my-3">Billing Address</h2>
              <div className="form-main">
                <div className="row">
                  {/* First Name */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="firstname" className="mb-2 blue-text">
                        First Name
                      </label>
                      <input
                        type="text"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="firstname"
                        aria-describedby="firstname"
                      />
                    </div>
                  </div>

                  {/* Last Name */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="lastname" className="mb-2 blue-text">
                        Last Name
                      </label>
                      <input
                        type="text"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="lastname"
                        aria-describedby="lastname"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="phone" className="mb-2 blue-text">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="phone"
                        aria-describedby="phone"
                      />
                    </div>
                  </div>

                  {/* Email Address */}
                  <div className="col-sm-6">
                    <div className="mb-4">
                      <label htmlFor="email" className="mb-2 blue-text">
                        Email Address
                      </label>
                      <input
                        type="email"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="email"
                        aria-describedby="email"
                      />
                    </div>
                  </div>

                  {/* country */}

                  <div className="col-sm-4">
                    <div className="mb-4">
                      <label htmlFor="firstname" className="mb-2 blue-text">
                        Country
                      </label>
                      <select
                        className="form-select form-control input-h shadow-none border-secondary-subtle  mb-3"
                        aria-label=""
                      >
                        <option selected>Country</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                      </select>
                    </div>
                  </div>

                  {/* state-province */}

                  <div className="col-sm-4">
                    <div className="mb-4">
                      <label htmlFor="lastname" className="mb-2 blue-text">
                        State/Province
                      </label>
                      <input
                        type="text"
                        className="form-control input-h shadow-none border-secondary-subtle"
                        id="state"
                        aria-describedby="state"
                      />
                    </div>
                  </div>

                  {/* zip-code */}
                  <div className="col-sm-4">
                    <div className="mb-4">
                      <label htmlFor="zip" className="mb-2 blue-text">
                        Postal (ZIP) Code
                      </label>
                      <input
                        type="text"
                        name="zip"
                        id="zip"
                        className="form-control input-h shadow-none border-secondary-subtle"
                      />
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <Link to="/confirm">
                  <button type="button" className="white-btn border-0">
                    Pay Now
                  </button>
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Confirmbooking;
