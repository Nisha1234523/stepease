import React from "react";
import Footer from "../../components/footer";
import { Link } from "react-router-dom";

function Services() {
  return (
    <>
      {" "}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-50">
          <div className="row">
            <div className="col-lg-6 col-md-10">
              <div className="position-relative">
                <img
                  src="/static/img/our-package/packages.png"
                  alt="Explore World"
                  className="img-fluid"
                />

                <div className="position-absolute top-50 start-50">
                  <img
                    src="/static/img/services.png"
                    alt="Explore World"
                    className="img-fluid"
                  />
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-12  mt-5 my-auto">
              <div>
                <h2 className="heading fw-bold">Description</h2>
              </div>
              <p className="fw-medium secondary-text opacity-50">
                Nestled in the heart of Rajasthan,{" "}
                <span className="text-black fw-bold">Luxurious Hotel</span> is a
                masterpiece of opulence and heritage, offering an unforgettable
                experience of regal living. Inspired by the grandeur of Rajput
                and Mughal architecture, our hotel blends timeless elegance with
                modern luxury. From lavishly designed suites with intricate
                Rajasthani décor to world-class amenities, every corner of
                Luxurious Hotel exudes sophistication and charm. Indulge in
                authentic royal hospitality, savor exquisite local and
                international cuisine, and unwind in our serene spa, all while
                soaking in breath-taking views of the golden sands or majestic
                forts. Whether you seek a romantic getaway, a cultural escape,
                or an extraordinary celebration, Luxurious Hotel promises an
                enchanting stay, where history and luxury come together to
                create a truly regal experience.
              </p>

              <div className="d-flex align-items-center flex-wrap gap-4">
                <span className="d-flex align-items-center gap-2">
                  <img
                    src="/static/img/icons/ic-tea-drink.svg"
                    alt="tea-drink"
                  />
                  <p className="fw-normal fs-14 mb-0">Breakfast Included</p>
                </span>
                <span className="d-flex align-items-center gap-2">
                  <img src="/static/img/icons/ic-wifi.svg" alt="tea-drink" />
                  <p className="fw-normal fs-14 mb-0">Free WI-FI</p>
                </span>
                <span className="d-flex align-items-center gap-2">
                  <img src="/static/img/icons/ic-parking.svg" alt="tea-drink" />
                  <p className="fw-normal fs-14 mb-0">Free Parking</p>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Contact-us Section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-50">
          <div className="row align-items-center">
            <div className=" col-md-6 col-12 mt-lg-0 mt-5">
              {/* form-section */}
              <div>
                <form>
                  <h2 className="fw-bold fs-24">Your details</h2>
                  <div className="form-main mt-5">
                    <div className="row">
                      {/* first Name */}
                      <div className="col-sm-6">
                        <div className="mb-4">
                          <label htmlFor="name" className="mb-2">
                            First name *
                          </label>
                          <input
                            type="text"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            id="name"
                            aria-describedby="name"
                          />
                        </div>
                      </div>

                      {/* Last Name */}
                      <div className="col-sm-6">
                        <div className="mb-4">
                          <label htmlFor="lastname" className="mb-2">
                            Last name *
                          </label>
                          <input
                            type="text"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            id="lastname"
                            aria-describedby="name"
                          />
                        </div>
                      </div>

                      <div className="col-sm-6">
                        {/* phone no. */}
                        <div className="mb-4">
                          <label htmlFor="tel" className="mb-2">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            aria-describedby="tel"
                            id="tel"
                          />
                        </div>
                      </div>

                      <div className="col-sm-6">
                        {/* email */}
                        <div className="mb-4">
                          <label htmlFor="email" className="mb-2">
                            Email Address *
                          </label>
                          <input
                            type="email"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            aria-describedby="email"
                            id="email"
                          />
                        </div>
                      </div>

                      {/* salutation */}
                      <div className="col-sm-6">
                        <div className="mb-4">
                          <label htmlFor="salutation" className="mb-2">
                            Salutation
                          </label>
                          <input
                            type="text"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            id="salutation"
                            aria-describedby="name"
                          />
                        </div>
                      </div>

                      {/* textarea */}
                      <div className="col-12">
                        {/* email */}
                        <div className="mb-4">
                          <label className="mb-3 light-gray">
                            Special requests to hotel
                          </label>
                          <textarea
                            id="area"
                            name="area"
                            rows="4"
                            className="form-control"
                          />
                        </div>
                      </div>
                    </div>

                    {/* submit-button */}
                    <Link to="/confirm">
                      <button type="button" className="white-btn border-0">
                        Continue Booking
                      </button>
                    </Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default Services;
