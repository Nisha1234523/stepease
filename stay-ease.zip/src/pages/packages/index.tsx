import React from "react";
import { Autoplay, Navigation, Pagination } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import Footer from "../../components/footer";
import { Link } from "react-router-dom";

export default function Packages() {
  return (
    <>
      <div className="mt-50">
        <h2 className="text-center fw-bold heading primary-text my-5">
          Top Hotels
        </h2>
        <div className="bg-gray my-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-5 py-5">
            {/* Our Service Start */}
            <div className="d-grid align-items-stretch position-relative">
              <Swiper
                spaceBetween={50}
                loop={true}
                autoplay={{
                  delay: 10000,
                  disableOnInteraction: false,
                }}
                navigation={true}
                modules={[Pagination, Autoplay, Navigation]}
                breakpoints={{
                  660: {
                    slidesPerView: 2,
                  },

                  992: {
                    slidesPerView: 3,
                  },
                }}
                id="cardSwiper"
                className="overflow-hideen"
              >
                {" "}
                {/* Swiper Slides */}{" "}
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <Link to="/services">
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </Link>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item2.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1600/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Savana Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Goa, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item3.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1800/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Capital Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">New Delhi, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
      </div>

      {/* second-section */}
      <div className="mt-50 ">
        <div className="bg-gray my-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-5 py-5">
            {/* Our Service Start */}
            <div className="d-grid align-items-stretch position-relative">
              <Swiper
                spaceBetween={50}
                loop={true}
                autoplay={{
                  delay: 10000,
                  disableOnInteraction: false,
                }}
                navigation={true}
                modules={[Pagination, Autoplay, Navigation]}
                breakpoints={{
                  660: {
                    slidesPerView: 2,
                  },

                  992: {
                    slidesPerView: 3,
                  },
                }}
                id="cardSwiper"
                className="overflow-hideen"
              >
                {" "}
                {/* Swiper Slides */}{" "}
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>

                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item2.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1600/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Savana Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Goa, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item3.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1800/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Capital Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">New Delhi, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
      </div>

      {/* third-section */}
      <div className="mt-50 ">
        <div className="bg-gray my-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-5 py-5">
            {/* Our Service Start */}
            <div className="d-grid align-items-stretch position-relative">
              <Swiper
                spaceBetween={50}
                loop={true}
                autoplay={{
                  delay: 10000,
                  disableOnInteraction: false,
                }}
                navigation={true}
                modules={[Pagination, Autoplay, Navigation]}
                breakpoints={{
                  660: {
                    slidesPerView: 2,
                  },

                  992: {
                    slidesPerView: 3,
                  },
                }}
                id="cardSwiper"
                className="overflow-hideen"
              >
                {" "}
                {/* Swiper Slides */}{" "}
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item2.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1600/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Savana Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Goa, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item3.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1800/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Capital Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">New Delhi, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="static/img/card-item.png"
                        alt="team-member"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">1200/night</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Luxurious Hotel</h5>
                      <div className="d-flex align-items-center gap-2">
                        <img
                          src="static/img/icons/ic-location.svg"
                          alt="Location Icon"
                          className="img-fluid"
                        />
                        <p className="fs-18 fw-normal mb-0">Rajasthan, India</p>
                      </div>
                      <p className="fw-normal opacity-75">
                        Enjoy your stay at Luxurious Hotels in Rajasthan with
                        our special services.
                      </p>
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div>
                          <button type="button" className="white-btn border-0">
                            Explore
                          </button>
                        </div>
                        <div className="d-flex align-items-center gap-1">
                          <img
                            src="static/img/icons/ic-star.svg"
                            alt="Star Icon"
                            className="img-fluid"
                          />
                          <p className="fw-normal fs-14 mb-0">4.5</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
