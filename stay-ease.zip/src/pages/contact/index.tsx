import React from "react";
import Header from "../../components/header";
import Footer from "../../components/footer";

function ContactUs() {
  return (
    <>
      <div className="px-lg-5 px-2 about-div">
        <div className="mx-auto px-sm-4 px-3 max-w-xxl h-100">
          <div className="d-flex flex-column h-100">
            <div>
              <Header />
            </div>
            {/* banner-section */}
            <div className="d-flex flex-column my-auto mx-auto">
              <div className="">
                <h2 className="fw-bold text-white main-heading">Contact Us</h2>
                <p className="fw-bold text-white  d-flex justify-content-center gap-3">
                  Home
                  <span>
                    <img
                      src="/static/img/icons/ic-backward.svg"
                      alt="Prev Icon"
                      className="img-fluid"
                    />
                  </span>
                  Contact Us
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* home-section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5">
          <div className="row align-items-center g-5">
            <div className="col-lg-7 col-md-6 col-12">
              <div>
                <img
                  src="/static/img/contact-us/map.png"
                  alt="Map Img"
                  className="img-fluid"
                />
              </div>
            </div>
            <div className="col-lg-5 col-md-6 col-12 mt-lg-0 mt-5">
              <div>
                <h2 className="heading fw-bold">Get In Touch</h2>

                <p className="fw-medium secondary-text opacity-50 mb-0">
                  We’d love to hear from you! At StayEase, your experience
                  matters to us, and we’re here to assist you every step of the
                  way. Whether you have a question about a booking, need travel
                  recommendations, or want to partner with us, our team is ready
                  to help.
                </p>
                <h6 className="fs-18 fw-bold my-4">How to Reach Us</h6>
                <div>
                  <p className="fs-18 fw-bold">
                    Address: &nbsp;
                    <span className="light-black">
                      Madhushilp, Manpada Rd, Opp Tar Ghar, Dombivli (east)
                      Mumbai, Maharashtra, 421201{" "}
                    </span>
                  </p>
                  <p className="fs-18 fw-bold">
                    Phone: &nbsp;
                    <span className="light-black">9865784609, 9987633474</span>
                  </p>
                  <p className="fs-18 fw-bold">
                    Email: &nbsp;
                    <span className="light-black"> abcd13@gmail.com</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <div className="bg-blue mt-5">
        <div className="py-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3">
            <div className="row align-items-center">
              <div className="col-md-4 col-sm-6">
                <div className="d-flex flex-column align-items-center gap-2 border-end border-display">
                  <img
                    src="/static/img/contact-us/ic-support.svg"
                    alt="Support Icon"
                    className="img-fluid"
                  />
                  <ul className="text-white">
                    <li className="fs-28">Expert Support Team</li>
                  </ul>
                </div>
              </div>

              {/*  */}
              <div className="col-md-4 col-sm-6">
                <div className="d-flex flex-column align-items-center gap-2 border-end border-display">
                  <img
                    src="/static/img/contact-us/ic-available.svg"
                    alt="Available Icon"
                    className="img-fluid"
                  />
                  <ul className="text-white">
                    <li className="fs-28">Expert Support Team</li>
                  </ul>
                </div>
              </div>

              {/*  */}
              <div className="col-md-4 col-sm-6">
                <div className="d-flex flex-column align-items-center gap-2 ">
                  <img
                    src="/static/img/contact-us/ic-hours.svg"
                    alt="Hours Icon"
                    className="img-fluid"
                  />
                  <ul className="text-white">
                    <li className="fs-28">Flexible Visiting Hours</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact-us Section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5">
          <div className="row align-items-center g-5">
            <div className="col-lg-7 col-md-6  col-12">
              <div>
                <img
                  src="/static/img/contact-us/contact.png"
                  alt="Contact Img"
                  className="img-fluid"
                />
              </div>
            </div>
            <div className="col-lg-5 col-md-6  col-12 mt-lg-0 mt-5">
              {/* form-section */}
              <div>
                <form>
                  <h2 className="fw-bold main-heading">Send us a Message</h2>
                  <div className="form-main mt-5">
                    <div className="row">
                      {/* first Name */}
                      <div className="col-sm-6">
                        <div className="mb-4">
                          <input
                            type="text"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            id="name"
                            aria-describedby="name"
                            placeholder="First Name"
                          />
                        </div>
                      </div>

                      {/* Last Name */}
                      <div className="col-sm-6">
                        <div className="mb-4">
                          <input
                            type="text"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            id="lastname"
                            aria-describedby="name"
                            placeholder="Last Name"
                          />
                        </div>
                      </div>

                      <div className="col-sm-6">
                        {/* email */}
                        <div className="mb-4">
                          <input
                            type="email"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            aria-describedby="email"
                            id="email"
                            placeholder="Email Address"
                          />
                        </div>
                      </div>
                      <div className="col-sm-6">
                        {/* email */}
                        <div className="mb-4">
                          <input
                            type="tel"
                            className="form-control input-h shadow-none border-secondary-subtle"
                            aria-describedby="email"
                            id="tel"
                            placeholder="Mobile Number"
                          />
                        </div>
                      </div>

                      {/* textarea */}
                      <div className="col-12">
                        {/* email */}
                        <div className="mb-4">
                          <textarea
                            id="area"
                            name="area"
                            rows="4"
                            className="form-control"
                            placeholder="Write us your Message"
                          />
                        </div>
                      </div>
                    </div>

                    {/* submit-button */}
                    <button type="button" className="white-btn border-0">
                      Submit
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default ContactUs;
