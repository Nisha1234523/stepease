import { Swiper, SwiperSlide } from "swiper/react";
import Header from "../../components/header";
import { Autoplay, Navigation, Pagination } from "swiper/modules";
import Footer from "../../components/footer";

function About() {
  return (
    <>
      <div className="px-lg-5 px-2 about-div">
        <div className="mx-auto px-sm-4 px-3 max-w-xxl h-100">
          <div className="d-flex flex-column h-100">
            <div>
              <Header />
            </div>
            {/* banner-section */}
            <div className="d-flex flex-column my-auto mx-auto">
              <div className="">
                <h2 className="fw-bold text-white main-heading">About Us</h2>
                <p className="fw-bold text-white  d-flex  justify-content-center gap-3">
                  Home
                  <span>
                    <img
                      src="/static/img/icons/ic-backward.svg"
                      alt="Prev Icon"
                      className="img-fluid"
                    />
                  </span>
                  About Us
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* home-section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5">
          <div className="row align-items-center g-5">
            <div className="col-lg-7 col-md-6 col-12">
              <div>
                <img
                  src="/static/img/about-us/our-service.png"
                  alt="Service IMG"
                  className="img-fluid"
                />
              </div>
            </div>
            <div className="col-lg-5 col-md-6 col-12 mt-lg-0 mt-5">
              <div>
                <h2 className="heading fw-bold">Our Story</h2>
              </div>
              <p className="fw-medium secondary-text opacity-50">
                At StayEase, we believe that finding the perfect stay should be
                effortless, enjoyable, and tailored to your needs. Our journey
                began with a simple idea: to connect travelers with the best
                hotels worldwide, making every trip seamless and stress-free. We
                started as a small team of travel enthusiasts who understood the
                challenges of hotel booking—endless searches, hidden fees, and
                unreliable reviews. Determined to change that, we built
                StayEase, a platform that brings transparency, convenience, and
                affordability to every traveller.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* why-choose-us */}
      <div className="mt-50 ">
        <h2 className="text-center fw-bold heading primary-text my-5">
          Why Choose Us ?
        </h2>
        <div className="bg-gray my-5">
          <div className="max-w-xxl mx-auto px-sm-4 px-3 mt-5 py-5">
            {/* Our Service Start */}
            <div className="d-grid align-items-stretch position-relative">
              <Swiper
                spaceBetween={50}
                loop={true}
                autoplay={{
                  delay: 10000,
                  disableOnInteraction: false,
                }}
                navigation={true}
                modules={[Pagination, Autoplay, Navigation]}
                breakpoints={{
                  660: {
                    slidesPerView: 2,
                  },

                  992: {
                    slidesPerView: 3,
                  },
                }}
                id="cardSwiper"
                className="overflow-hideen"
              >
                {" "}
                {/* Swiper Slides */}{" "}
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/affordable.png"
                        alt="Afforodable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">Affordable</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Affordable Bookings</h5>

                      <p className="fw-normal opacity-75">
                        We have affordable bookings and many discount offers for
                        you. So that you never need to think about your budget
                        before booking a perfect hotel for your stay.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/scalable.png"
                        alt="Scalable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0">
                        <h4 className="fs-28 text-white ps-3">Scalability</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Scalability</h5>

                      <p className="fw-normal opacity-75">
                        We are scalable to a large amount and will provide many
                        more hotel choices in all your favourite cities. So that
                        you will never to be out of your favourite choices.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/support.png"
                        alt="Scalable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0">
                        <h4 className="fs-28 text-white ps-3 ">24/7 Support</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">24/7 Support</h5>

                      <p className="fw-normal opacity-75">
                        Our support staff is always available for your
                        convenience. We make sure we are always available for
                        our customers and are ready to solve their issues.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/affordable.png"
                        alt="Afforodable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0 ">
                        <h4 className="fs-28 text-white ps-3 ">Affordable</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Affordable Bookings</h5>

                      <p className="fw-normal opacity-75">
                        We have affordable bookings and many discount offers for
                        you. So that you never need to think about your budget
                        before booking a perfect hotel for your stay.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/scalable.png"
                        alt="Scalable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0">
                        <h4 className="fs-28 text-white ps-3">Scalability</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">Scalability</h5>

                      <p className="fw-normal opacity-75">
                        We are scalable to a large amount and will provide many
                        more hotel choices in all your favourite cities. So that
                        you will never to be out of your favourite choices.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide className="py-5">
                  <div className="card-box rounded">
                    <div className="position-relative w-100">
                      <img
                        src="/static/img/about-us/support.png"
                        alt="Scalable Img"
                        className="img-fluid w-100"
                      />
                      <div className="position-absolute bottom-0">
                        <h4 className="fs-28 text-white ps-3 ">24/7 Support</h4>
                        <div className="border border-white mb-4"></div>
                      </div>
                    </div>
                    <div className=" p-4">
                      <h5 className="fs-24">24/7 Support</h5>

                      <p className="fw-normal opacity-75">
                        Our support staff is always available for your
                        convenience. We make sure we are always available for
                        our customers and are ready to solve their issues.
                      </p>

                      <div>
                        <button type="button" className="white-btn border-0">
                          Explore
                        </button>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
      </div>

      {/* Our Team Section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5">
          <div className="row align-items-center gap-lg-5">
            <div className="col-lg-6 col-md-6">
              <div className="position-relative">
                <img
                  src="/static/img/about-us/team.png"
                  alt="Our Team"
                  className="img-fluid"
                />

                <div className="position-absolute bottom-0 end-0 me-5 pe-5">
                  <img
                    src="/static/img/about-us/team-2.png"
                    alt="Our Team"
                    className="img-fluid"
                  />
                </div>
              </div>
            </div>
            <div className="col-lg-5 col-md-6  mt-lg-0 mt-5">
              <div>
                <h2 className="heading fw-bold">Our Team</h2>
              </div>
              <p className="fw-medium secondary-text opacity-50">
                At StayEase, we are more than just a hotel booking platform—we
                are a team of passionate travelers, tech innovators, and
                hospitality experts dedicated to making your travel experiences
                seamless and stress-free. From developers crafting a smooth and
                intuitive booking experience to travel enthusiasts handpicking
                the best stays, each member of our team plays a vital role in
                bringing you the perfect accommodation options. We work
                tirelessly to ensure that every hotel listed on StayEase meets
                high-quality standards, offering you comfort, convenience, and
                reliability.
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default About;
