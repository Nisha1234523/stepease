import React from "react";
import { Link } from "react-router-dom";

function index() {
  return (
    <>
      {" "}
      <section className="min-vh-100">
        <div className="login-heroBg">
          <div className="col-xxl-4 col-xl-5 col-sm-10 col-12 d-flex mx-auto  my-auto h-100">
            <div className="form-bg my-auto w-100 p-3 mx-lg-0 mx-3">
              <form className="text-center my-5">
                {/* form content */}
                <h3 className="fs-36 fw-bold text-white ">Login</h3>

                <div className="mb-3">
                  <div className="position-relative">
                    <input
                      type="email"
                      className="form-control input-h shadow-none border-secondary-subtle w-100 bg-transparent custom-search"
                      aria-describedby="email"
                      id="email"
                      placeholder="Enter Your Email"
                    />
                    <div className="position-absolute show-hide-ic">
                      <img src="/static/img/icons/ic-email.svg" />
                    </div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="position-relative">
                    <input
                      type="password"
                      className="form-control input-h shadow-none border-secondary-subtle w-100 bg-transparent custom-search"
                      id="Password"
                      placeholder="Password"
                    />

                    <div className="position-absolute show-hide-ic">
                      <img src="/static/img/icons/ic-hide.svg" />
                    </div>
                  </div>
                </div>

                <div className="d-flex justify-content-start align-items-center gap-5">
                  <span className="text-decoration-none d-flex align-items-center gap-2">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault"
                      />
                    </div>
                    <Link
                      to={"/forgot-password"}
                      className="small fw-medium text-decoration-none text-white"
                    >
                      Forgot Password ?
                    </Link>
                  </span>
                  <span className="text-decoration-none">
                    <Link
                      to={"/forgot-password"}
                      className="small fw-medium text-decoration-none text-white"
                    >
                      Create new account
                    </Link>
                  </span>
                </div>

                <div className="my-4">
                  <button type="button" className="white-btn border-0 w-100">
                    Login
                  </button>
                </div>

                <div className="d-flex flex-column justify-content-center align-items-center">
                  <div>
                    <p className="text-white fw-normal fs-14">Or login using</p>
                  </div>
                  <div className="d-flex align-items-center justify-content-center justify-content-md-start gap-3 mt-sm-0 mt-4">
                    <Link
                      to="/"
                      className="bg-white d-flex justify-content-center align-items-center rounded-circle p-2"
                    >
                      <img
                        src="/static/img/icons/ic-google.svg"
                        alt="Facebook Icon"
                      />
                    </Link>

                    <Link
                      to="/"
                      className="bg-white d-flex justify-content-center align-items-center rounded-circle p-2"
                    >
                      <img
                        src="/static/img/icons/ic-micro.svg"
                        alt="Insta Icon"
                      />
                    </Link>

                    <Link
                      to="/"
                      className="bg-white d-flex justify-content-center align-items-center rounded-circle p-2"
                    >
                      <img
                        src="/static/img/icons/ic-face.svg"
                        alt="Twitter Icon"
                      />
                    </Link>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default index;
