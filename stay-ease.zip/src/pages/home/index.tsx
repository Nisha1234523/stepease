import { Link } from "react-router-dom";
import Header from "../../components/header";
import Marquee from "react-fast-marquee";
import SwiperComponent from "./swiper";
import Footer from "../../components/footer";

const Home = () => {
  return (
    <>
      <div className="px-lg-5 px-2 parent-div">
        <div className="mx-auto px-sm-4 px-3 max-w-xxl h-100">
          <div className="d-flex flex-column h-100">
            <div>
              <Header />
            </div>

            {/* banner-section */}
            <div className="d-flex flex-column my-auto">
              <div className="col-lg-5">
                <h2 className="fw-bold text-white main-heading">
                  Enjoy your dream stay with us.
                </h2>
                <p className="fw-normal light-text py-sm-2">
                  We offer best hotel booking services and facilities for your
                  comfortable stay. With our service we make sure you never have
                  to worry about a perfect stay. Hotel bookings made easy and
                  convenient.
                </p>
                <div>
                  <button type="button" className="white-btn border-0">
                    Book Now
                  </button>
                </div>
              </div>
              <div className=" rounded-8 mt-sm-5 mt-1 custom-width p-sm-4 p-1 opacity-bg">
                <div className="d-flex flex-row flex-wrap gap-sm-5 bg-transparent justify-content-md-start justify-content-center">
                  {/* Location Tab */}
                  <div className="d-flex align-items-center gap-3 flex-wrap  bg-transparent">
                    <div className="styled-select bg-transparent">
                      <select
                        className="form-select w-auto select-form"
                        aria-label="e"
                      >
                        <option selected>Location</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                      </select>
                    </div>
                    {/* Date Tab */}
                    <div className="styled-select bg-transparent">
                      <select
                        className="form-select w-auto select-form"
                        aria-label=""
                      >
                        <option selected>Date</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                      </select>
                    </div>

                    {/* People Tab */}
                    <div className="styled-select bg-transparent">
                      <select
                        className="form-select w-auto select-form"
                        aria-label=""
                      >
                        <option selected>People</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                      </select>
                    </div>
                  </div>

                  {/* Search Tab */}
                  <div>
                    <button
                      type="button"
                      className="primary-btn text-white border-0"
                    >
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* home-section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5">
          <div className="row align-items-center">
            <div className="col-lg-7 col-md-10">
              <div className="position-relative">
                <img
                  src="/static/img/place1.png"
                  alt="Explore World"
                  className="img-fluid"
                />

                <div className="position-absolute bottom-0 end-0 me-5 pe-5">
                  <img
                    src="/static/img/place-2.png"
                    alt="Explore World"
                    className="img-fluid"
                  />
                </div>
              </div>
            </div>
            <div className="col-lg-5  col-12 mt-lg-0 mt-5">
              <div>
                <h2 className="heading fw-bold">Welcome To StayEase</h2>
              </div>
              <p className="fw-medium secondary-text opacity-50">
                We offer best hotel booking services and facilities for your
                comfortable stay. With our service we make sure you never have
                to worry about a perfect stay. Hotel bookings made easy and
                convenient.
              </p>
              <button type="button" className="white-btn border-0">
                Book Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Client Section Start */}
      <section className="bg-blue py-5 overflow-hidden mt-50">
        <Marquee speed={50} autoFill={true} pauseOnHover={true}>
          <div className="app-logo">
            <img
              src="/static/img/client-1.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-2.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-3.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-4.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-1.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-2.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-3.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
          <div className="app-logo">
            <img
              src="/static/img/client-4.png"
              alt="Our Client"
              className="img-fluid"
            />
          </div>
        </Marquee>
      </section>
      {/* Client Section End */}

      {/* Our Hotels */}
      <div>
        <SwiperComponent />
      </div>

      {/* Menorable Section */}
      <section>
        <div className="max-w-xxl mx-auto px-sm-4 px-3 my-5 mt-50 position-relative overflow-hidden memo-section">
          <div className="text-center col-xl-6 mx-auto">
            <h2 className=" fw-bold heading primary-text">Memorable Stays</h2>
            <p className="light-black fs-18 fw-normal py-2">
              We offer one of the best services for the ones willing to stay in
              a dream place. You’ll have the best hotel staying experience and
              you will take home many memories with you. Our hotels are
              beautiful, aesthetic & they provide you with the best services.
              You visit our hotels once and you’ll forever cherish the memories.
            </p>
            <div>
              <button type="button" className="white-btn border-0">
                Explore
              </button>
            </div>
          </div>

          {/* service-section */}
          <div className="row py-5 gy-5 align-items-center  text-center">
            <div className="col-lg-4 col-sm-6">
              <img
                src="/static/img/service-1.png"
                alt="Our Service"
                className="img-fluid"
              />
            </div>
            <div className="col-lg-4 col-sm-6">
              <img
                src="/static/img/service-2.png"
                alt="Our Service"
                className="img-fluid"
              />
            </div>
            <div className="col-lg-4 col-sm-6">
              <img
                src="/static/img/service-3.png"
                alt="Our Service"
                className="img-fluid"
              />
            </div>
          </div>
        </div>
      </section>

      {/* experience-section */}
      <div className="bg-blue my-5 overflow-hidden transform-position">
        <div className="max-w-xxl mx-auto px-sm-4 px-3  py-5 mt-50">
          <div className="row py-5 mt-5 mt-190">
            <div className="col-lg-6">
              <h2 className="fs-36 fw-bold text-white">
                You’ll love the experience of our services. You’ll cherish the
                stay forever.
              </h2>
              <img
                src="/static/img/icons/ic-decor.svg"
                alt="Decor Img"
                className="img-fluid mt-4"
              />
            </div>
            <div className="col-lg-6">
              <div className="d-flex align-items-center gap-3">
                <div className="border h-75 w-75"></div>
                <div>
                  <img
                    src="/static/img/icons/ic-cherish.svg"
                    alt="Our Service"
                    className="img-fluid"
                  />
                </div>
              </div>
              <div className="d-flex align-items-center gap-5 flex-wrap">
                <div>
                  <h2 className="fw-bold text-white heading mb-0">850+</h2>
                  <p className="fs-26 fw-normal text-white">Clients</p>
                </div>
                <div>
                  <h2 className="fw-bold text-white heading mb-0">30k+</h2>
                  <p className="fs-26 fw-normal text-white">Hotels</p>
                </div>
                <div>
                  <h2 className="fw-bold text-white heading mb-0">1.3m+</h2>
                  <p className="fs-26 fw-normal text-white">Rooms</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* testmonial-section */}

      <div className="max-w-xxl mx-auto px-sm-4 px-3 py-5 custom-margin">
        <div id="carouselCaptions" className="carousel carousel-dark slide">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <div className="text-center col-xl-6 col-lg-9 col-sm-8 mx-auto">
                <h2 className="fw-bold heading primary-text">Testimonials</h2>
                <p className="light-black fs-18 fw-normal py-2">
                  "StayEase made booking my hotel easier than ever! The website
                  is intuitive, with great deals and a wide selection of hotels
                  to choose from. I loved how I could filter by price,
                  amenities, and reviews to find the perfect stay. The booking
                  process was smooth, and I received instant confirmation with
                  all the details I needed. Plus, their customer support was
                  super helpful when I had a question about my reservation.
                  Thanks to StayEase, my trip was stress-free—I’ll definitely
                  book with them again!"
                </p>

                <div className="d-flex align-items-center justify-content-center gap-3">
                  <img
                    src="/static/img/icons/ic-profile.svg"
                    alt="Person Profile"
                    className="img-fluid"
                  />
                  <h5 className="fs-26 fw-normal mb-0">James Robert</h5>
                </div>
              </div>

              <div className="d-flex justify-content-between align-items-center pt-4">
                <button
                  className="carousel-control-prev d-flex align-items-center gap-2 position-absolute w-auto  carousel-btn"
                  type="button"
                  data-bs-target="#carouselCaptions"
                  data-bs-slide="prev"
                >
                  <span
                    className="carousel-control-prev-icon carousel-prev-icon"
                    aria-hidden="true"
                  ></span>
                </button>

                <button
                  className="carousel-control-next d-flex align-items-center position-absolute w-auto  carousel-btn"
                  type="button"
                  data-bs-target="#carouselCaptions"
                  data-bs-slide="next"
                >
                  <span
                    className="carousel-control-next-icon carousel-next-icon"
                    aria-hidden="true"
                  ></span>
                </button>
              </div>
            </div>
            <div className="carousel-item">
              <div className="text-center col-xl-6 col-lg-9 col-sm-8 mx-auto">
                <h2 className="fw-bold heading primary-text">Testimonials</h2>
                <p className="light-black fs-18 fw-normal py-2">
                  "StayEase made booking my hotel easier than ever! The website
                  is intuitive, with great deals and a wide selection of hotels
                  to choose from. I loved how I could filter by price,
                  amenities, and reviews to find the perfect stay. The booking
                  process was smooth, and I received instant confirmation with
                  all the details I needed. Plus, their customer support was
                  super helpful when I had a question about my reservation.
                  Thanks to StayEase, my trip was stress-free—I’ll definitely
                  book with them again!"
                </p>

                <div className="d-flex align-items-center justify-content-center gap-3">
                  <img
                    src="/static/img/icons/ic-profile.svg"
                    alt="Person Profile"
                    className="img-fluid"
                  />
                  <h5 className="fs-26 fw-normal mb-0">James Robert</h5>
                </div>
              </div>

              <div className="d-flex justify-content-between align-items-center pt-4">
                <button
                  className="carousel-control-prev d-flex align-items-center gap-2 position-absolute w-auto  carousel-btn"
                  type="button"
                  data-bs-target="#carouselCaptions"
                  data-bs-slide="prev"
                >
                  <span
                    className="carousel-control-prev-icon carousel-prev-icon"
                    aria-hidden="true"
                  ></span>
                </button>

                <button
                  className="carousel-control-next d-flex align-items-center position-absolute w-auto  carousel-btn"
                  type="button"
                  data-bs-target="#carouselCaptions"
                  data-bs-slide="next"
                >
                  <span
                    className="carousel-control-next-icon carousel-next-icon"
                    aria-hidden="true"
                  ></span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Home;
