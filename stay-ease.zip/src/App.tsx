import { Route, Routes } from "react-router-dom";
import "../src/assets/bootstrapCss/bootstrap.min.css";
import "./App.css";

import Home from "./pages/home";

import About from "./pages/about";
import ContactUs from "./pages/contact";
import Login from "./pages/login";
import Packages from "./pages/packages";
import Services from "./pages/Services";
import Confirmbooking from "./pages/confirm-booking";

function App() {
  return (
    <>
      <div>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/packages" element={<Packages />} />
          <Route path="/services" element={<Services />} />
          <Route path="/confirm" element={<Confirmbooking />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
